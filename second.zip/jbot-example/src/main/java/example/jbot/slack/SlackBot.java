package example.jbot.slack;

import me.ramswaroop.jbot.core.common.Controller;
import me.ramswaroop.jbot.core.common.EventType;
import me.ramswaroop.jbot.core.common.JBot;
import me.ramswaroop.jbot.core.slack.Bot;
import me.ramswaroop.jbot.core.slack.SlackApiEndpoints;
import me.ramswaroop.jbot.core.slack.models.Event;
import me.ramswaroop.jbot.core.slack.models.User;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.socket.WebSocketSession;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Calendar;
import java.util.regex.Matcher;

/**
 * A simple Slack Bot. You can create multiple bots by just
 * extending {@link Bot} class like this one. Though it is
 * recommended to create only bot per jbot instance.
 *
 * @author ramswaroop
 * @version 1.0.0, 05/06/2016
 * 
 *
 */


@JBot
@Profile("slack")
public class SlackBot extends Bot {
	DataLoader dataLoader;

//    public SlackBot() {
//    	dataLoader = new DataLoader();
//		dataLoader.loadDataTabls();
//
//	}

	private static final Logger logger = LoggerFactory.getLogger(SlackBot.class);

    /**
     * Slack token from application.properties file. You can get your slack token
     * next <a href="https://my.slack.com/services/new/bot">creating a new bot</a>.
     */
    @Value("${slackBotToken}")
    private String slackToken;

    @Override
    public String getSlackToken() {
        return slackToken;
    }

    @Override
    public Bot getSlackBot() {
        return this;
    }
    
    @Autowired
    SlackApiEndpoints slackApiEndpoints;

    /**
     * Invoked when the bot receives a direct mention (@botname: message)
     * or a direct message. NOTE: These two event types are added by jbot
     * to make your task easier, Slack doesn't have any direct way to
     * determine these type of events.
     *
     * @param session
     * @param event
     */
    @Controller(events = {EventType.DIRECT_MENTION, EventType.DIRECT_MESSAGE}, next = "policyRetrive")
    public void onReceiveDM(WebSocketSession session, Event event) {
			dataLoader = new DataLoader();
			dataLoader.loadDataTabls();
    		startConversation(event, "policyRetrive");   // start conversation
        	String username = getUser(event).getName();
			reply(session, event, getGreetingMessage()+" " +"@"+ username);
			reply(session, event, "Do you want to retrive policy status ?");
		
    }
    
    /*
     * method to retrive user info
     */
    private User getUser(Event event){
        UserResponse userResponse= new RestTemplate()
                .getForEntity(slackApiEndpoints
                        .getUserConnectApi()+"&user="+event.getUserId(), 
                        UserResponse.class, slackToken)
                .getBody();
        return userResponse.getUser();
    }
    
    /**
     * get greeting message based on time
     * @return
     */
    public String getGreetingMessage(){
    	int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
    	String greeting = "?";
		if (hour > 0 && hour <= 12)
			greeting = "Good Morning";
		else
		if (hour > 12 && hour <= 18)
			greeting = "Good Afternoon";
		else
		if (hour > 18 && hour <= 21)
			greeting = "Good Evening";
		else
		if (hour > 21 && hour <= 24)
			greeting = "Good Night";		
		return greeting;
    	
    }
   
    

    
    @Controller(next = "readPolicy")
    public void policyRetrive(WebSocketSession session, Event event) {
    	  if (event.getText().contains("yes")) {
              reply(session, event, "Great! Please enter policy number");
              nextConversation(event);
          } else {
              reply(session, event, "Okay, Thank you");
              stopConversation(event);
          }    
    
    }
   
    @Controller()
    public void readPolicy(WebSocketSession session, Event event) throws FileNotFoundException, IOException {
       
    	String policyNumber = event.getText().toString();
    	//String number = dataLoader.getTestData("policy", policyNumber, "policyStatus");
    	String policyStatus;
		String policyType;
		try {
			policyStatus = dataLoader.getTestData("policy", policyNumber, "policyStatus");
			policyType = dataLoader.getTestData("policy", policyNumber, "policyType");
			reply(session, event, "Please find policy details :");
	    	reply(session, event, "policy Number: "+ "  "+ policyNumber);
	    	reply(session, event, "policy status: "+ "  "+ policyStatus);
	    	reply(session, event, "policy Type: "+ "  "+ policyType);
	    	reply(session, event, "do you want to continue to retrive policy ?");
	    	if(event.getText().contains("yes")){
	    			    	}
		} catch (Exception e) {
			reply(session, event, policyNumber+" Entered policy is not existing in our DB" );
		}
    	
    	stopConversation(event);
    	 
    }
    

    
    /**
     * Invoked when bot receives an event of type message with text satisfying
     * the pattern {@code ([a-z ]{2})(\d+)([a-z ]{2})}. For example,
     * messages like "ab12xy" or "ab2bc" etc will invoke this method.
     *
     * @param session
     * @param event
     */
    @Controller(events = EventType.MESSAGE, pattern = "^([a-z ]{2})(\\d+)([a-z ]{2})$")
    public void onReceiveMessage(WebSocketSession session, Event event, Matcher matcher) {
        reply(session, event, "First group: " + matcher.group(0) + "\n" +
                "Second group: " + matcher.group(1) + "\n" +
                "Third group: " + matcher.group(2) + "\n" +
                "Fourth group: " + matcher.group(3));
    }

    /**
     * Invoked when an item is pinned in the channel.
     *
     * @param session
     * @param event
     */
    @Controller(events = EventType.PIN_ADDED)
    public void onPinAdded(WebSocketSession session, Event event) {
        reply(session, event, "Thanks for the pin! You can find all pinned items under channel details.");
    }

    /**
     * Invoked when bot receives an event of type file shared.
     * NOTE: You can't reply to this event as slack doesn't send
     * a channel id for this event type. You can learn more about
     * <a href="https://api.slack.com/events/file_shared">file_shared</a>
     * event from Slack's Api documentation.
     *
     * @param session
     * @param event
     */
    @Controller(events = EventType.FILE_SHARED)
    public void onFileShared(WebSocketSession session, Event event) {
        logger.info("File shared: {}", event);
    }


    /**
     * Conversation feature of JBot. This method is the starting point of the conversation (as it
     * calls {@link Bot#startConversation(Event, String)} within it. You can chain methods which will be invoked
     * one after the other leading to a conversation. You can chain methods with {@link Controller#next()} by
     * specifying the method name to chain with.
     *
     * @param session
     * @param event
     */
    /**
    @Controller(pattern = "(setup meeting)", next = "confirmTiming")
    public void setupMeeting(WebSocketSession session, Event event) {
        startConversation(event, "confirmTiming");   // start conversation
        reply(session, event, "Cool! At what time (ex. 15:30) do you want me to set up the meeting?");
    }
    
    **/

    /**
     * This method will be invoked after {@link SlackBot#setupMeeting(WebSocketSession, Event)}.
     *
     * @param session
     * @param event
     */
    /**
    @Controller(next = "askTimeForMeeting")
    public void confirmTiming(WebSocketSession session, Event event) {
        reply(session, event, "Your meeting is set at " + event.getText() +
                ". Would you like to repeat it tomorrow?");
        nextConversation(event);    // jump to next question in conversation
    }
**/
    /**
     * This method will be invoked after {@link SlackBot#confirmTiming(WebSocketSession, Event)}.
     *
     * @param session
     * @param event
     */
    
    /**
    @Controller(next = "askWhetherToRepeat")
    public void askTimeForMeeting(WebSocketSession session, Event event) {
        if (event.getText().contains("yes")) {
            reply(session, event, "Okay. Would you like me to set a reminder for you?");
            nextConversation(event);    // jump to next question in conversation  
        } else {
            reply(session, event, "No problem. You can always schedule one with 'setup meeting' command.");
            stopConversation(event);    // stop conversation only if user says no
        }
    }
    **/

    /**
     * This method will be invoked after {@link SlackBot#askTimeForMeeting(WebSocketSession, Event)}.
     *
     * @param session
     * @param event
     */
    
    /**
    @throws IOException 
     * @Controller
    public void askWhetherToRepeat(WebSocketSession session, Event event) {
        if (event.getText().contains("yes")) {
            reply(session, event, "Great! I will remind you tomorrow before the meeting.");
            stopConversation(event);
        } else {
            reply(session, event, "Okay, don't forget to attend the meeting tomorrow :)");
            stopConversation(event);
        }
            // stop conversation
    }
    **/
    
    
    
}