package example.jbot.slack;

import org.springframework.web.client.RestTemplate;

import me.ramswaroop.jbot.core.slack.models.Event;
import me.ramswaroop.jbot.core.slack.models.User;

public class UserResponse {

    private boolean ok;
    private User user;

    /**
     * @return the ok
     */
    public boolean isOk() {
        return ok;
    }

    /**
     * @return the user
     */
    public User getUser() {
        return user;
    }
    
  
    
}