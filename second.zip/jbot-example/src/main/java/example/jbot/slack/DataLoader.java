package example.jbot.slack;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.math.BigDecimal;
import java.util.Hashtable;
import java.util.Iterator;

public class DataLoader {

	
	public static Hashtable<String, Hashtable<String,String>> policyData;
	
	
	public void loadDataTabls(){
			try {
				policyData = loadDataTable("policyData.xls","sheet1");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
	
	public Hashtable<String, Hashtable<String,String>> loadDataTable(String workbookName, String sheetName) throws FileNotFoundException, IOException{
		int rowCount;
		int columCount;
		Hashtable<String, String> temp= null;
		Hashtable<String, Hashtable<String,String>> tempDataTable =  new Hashtable<String, Hashtable<String, String>>();
		try {
		HSSFWorkbook workbook = new HSSFWorkbook(new FileInputStream("F:\\Experiment\\jbot-master\\jbot-master\\jbot-example\\src\\main\\resources\\"+ workbookName));
		HSSFSheet sheet = workbook.getSheet(sheetName);
		rowCount = sheet.getLastRowNum() + 1;
		columCount = sheet.getRow(0).getLastCellNum();
		for(int i = 1; i< rowCount; i++) {
			temp = new Hashtable<String, String>();
			for(int j = 1;j <columCount; j++) {
				try {
				Cell cell = sheet.getRow(i).getCell(j);
				String value = "";
				if(cell.getCellType()!=HSSFCell.CELL_TYPE_BLANK){
					switch(cell.getCellType()){
					case HSSFCell.CELL_TYPE_NUMERIC:
						value =BigDecimal.valueOf(cell.getNumericCellValue()).toPlainString();
						break;
					case HSSFCell.CELL_TYPE_STRING:
						value = cell.getStringCellValue();
						break;
						
					case HSSFCell.CELL_TYPE_FORMULA:
						value = cell.getCellFormula();
						break;
					default:
						break;
						
					}
				}
				
				temp.put(sheet.getRow(0).getCell(j).toString(), value);	
				} catch(NullPointerException e) {
				}
			}
	
	if(sheetName.equalsIgnoreCase("TC2DataMap"))
		tempDataTable.put(sheet.getRow(i).getCell(0).toString()+ sheet.getRow(i).getCell(1).toString(),temp);
	else
		tempDataTable.put(sheet.getRow(i).getCell(0).toString(), temp);
	
		
	}
		return tempDataTable;
		}
		catch(Exception e) {
			return null;
			
		}
	}
	public String getTestData(String dataContainerName, String dataSet, String columName) {
		Hashtable<String, Hashtable<String, String>> dataTable =null;
		try{
		if(dataContainerName.equals("policy"))
			dataTable=policyData;
		}
		catch(Exception e){
			return "dataNotAvail";
		}
		return dataTable.get(dataSet).get(columName);
	}
	
	
	
		
    }